<?php 
 
class Admin extends CI_Controller{
 
	function __construct(){
		parent::__construct();
	
		if($this->session->userdata('status') != "login"){
			redirect(base_url("login"));
		}
		$this->load->model('M_guru');
		$this->load->model('M_pengguna');
		$this->load->model('M_siswa');
		$this->load->model('Mnguru');
		$this->load->model('m_log');
		$this->load->helper('url');
	}
 
	function index(){
		$data['guru'] = $this->M_guru->tampil_guru()->result();
		$data['pengguna'] = $this->M_pengguna->tampil_pengguna()->result();
		$data['siswa'] = $this->M_siswa->tampil_siswa();
		$data['non_guru'] = $this->Mnguru->tampil_nonguru()->result();
		$data['log'] = $this->m_log->tampil_log();
		$this->load->view('admin/header',$data);
		$this->load->view('admin/admin');
		$this->load->view('admin/footer');		
	}
	function log(){
		$data['log'] = $this->m_log->tampil_log();
		$this->load->view('admin/header',$data);
		$this->load->view('log/log_login',$data);
		$this->load->view('admin/footer');

	}
	function clear(){
		$this->load->Model('m_log');
		$this->m_log->clear();
		redirect('Admin/log');
	}
	function hapus($log_id){
		$this->load->Model('m_log');
		$this->m_log->hapus_log($log_id);
		redirect('Admin/log');
	}
}