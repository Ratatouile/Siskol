<?php 
	/**
	* 
	*/
	class Guru extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			if($this->session->userdata('status') != "login"){
			redirect(base_url("login"));
		 }
				$this->load->model('M_guru');
				$this->load->model('m_log');
				$this->load->library('dompdf_gen');
				$this->load->helper('url');
			
		}
		function index(){
			$data['log'] = $this->m_log->tampil_log();
			$data['guru'] = $this->M_guru->tampil_guru()->result();
			$this->load->view('admin/header',$data);
			$this->load->view('guru/guru',$data);
			$this->load->view('admin/footer');
		}
		
		function cetak(){
			$data['guru'] = $this->M_guru->tampil_guru()->result();
			$this->load->view('guru/cetak',$data);
			$paper_size = 'A4';
			$orientation = 'landscape';
			$html = $this->output->get_output();
			$this->dompdf->set_paper($paper_size,$orientation);
			// convert to PDF
			$this->dompdf->load_html($html);
			$this->dompdf->render();
			$this->dompdf->stream('laporan.pdf',array('Attachment'=>0));
		}
		
		function tambah(){
		if(isset($_POST['submit'])){
			$nip = $this->input->post('nip');
			$nama = $this->input->post('nama');
			$tgl_lahir = $this->input->post('tgl_lahir');
			$alamat = $this->input->post('alamat');
			$status = $this->input->post('status');
			$data = array(
				'nip'=>$nip,
				'nama'=>$nama,
				'lahir'=>$tgl_lahir,
				'alamat'=>$alamat,
				'status'=>$status
			);

			$this->M_guru->tambah_guru($data);
			redirect('Guru');

		}else{
		$data['log'] = $this->m_log->tampil_log();
		$this->load->view('admin/header',$data);
		$this->load->view('guru/tambah_guru');
		$this->load->view('admin/footer');
		}
	}
	function edit($id_guru){
		if(isset($_POST['submit'])){
			$nip = $this->input->post('nip');
			$nama = $this->input->post('nama');
			$tgl_lahir = $this->input->post('tgl_lahir');
			$alamat = $this->input->post('alamat');
			$status = $this->input->post('status');
			$data = array(
				'nip'=>$nip,
				'nama'=>$nama,
				'lahir'=>$tgl_lahir,
				'alamat'=>$alamat,
				'status'=>$status
			);

				$this->M_guru->edit_guru($data, $id_guru);
				
				redirect('guru');

			}else{
				$data['log'] = $this->m_log->tampil_log();
				$data['guru'] = $this->M_guru->ambil_guru($id_guru);
				$this->load->view('admin/header',$data);
				$this->load->view('guru/edit_guru', $data);
				$this->load->view('admin/footer');
			
			}
		}
		function hapus($id_guru){
			$this->load->model('M_guru');
			$this->M_guru->hapus_guru($id_guru);
			redirect('guru');
		}

	}
 