<?php 
	/**
	* 
	*/
	class Jadwal extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			if($this->session->userdata('status') != "login"){
			redirect(base_url("login"));
		}
			$this->load->Model('M_jadwal');
			$this->load->model('m_log');
			$this->load->helper('url');
			$this->load->library('dompdf_gen');
		}
		function index(){
			$data['log'] = $this->m_log->tampil_log();
			$data['jadwal'] = $this->M_jadwal->tampil_jadwal()->result();
			$this->load->view('admin/header',$data);
			$this->load->view('jadwal/jadwal',$data);
			$this->load->view('admin/footer');
		}
		function cetak(){
			$data['jadwal'] = $this->M_jadwal->tampil_jadwal()->result();
			$this->load->view('jadwal/cetak',$data);
			$paper_size = 'A4';
			$orientation = 'landscape';
			$html = $this->output->get_output();
			$this->dompdf->set_paper($paper_size,$orientation);
			// convert to PDF
			$this->dompdf->load_html($html);
			$this->dompdf->render();
			$this->dompdf->stream('Jadwal.pdf',array('Attachment'=>0));
		}
		function tambah(){
		if(isset($_POST['submit'])){
			$kelas = $this->input->post('kelas');
			$senin = $this->input->post('senin');
			$selasa = $this->input->post('selasa');
			$rabu = $this->input->post('rabu');
			$kamis = $this->input->post('kamis');
			$jumat = $this->input->post('jumat');
			$sabtu = $this->input->post('sabtu');
			$data = array(
				'kelas'=>$kelas,
				'senin'=>$senin,
				'selasa'=>$selasa,
				'rabu'=>$rabu,
				'kamis'=>$kamis,
				'jumat'=>$jumat,
				'sabtu'=>$sabtu
				);

			$this->M_jadwal->tambah_jadwal($data);
			redirect('Jadwal');

		}else{
			$data['log'] = $this->m_log->tampil_log();
			$this->load->view('admin/header',$data);
			$this->load->view('jadwal/tambah_jadwal');
			$this->load->view('admin/footer');
			}
		}
		function edit($id_jadwal){
		if(isset($_POST['submit'])){
			$kelas = $this->input->post('kelas');
			$senin = $this->input->post('senin');
			$selasa = $this->input->post('selasa');
			$rabu = $this->input->post('rabu');
			$kamis = $this->input->post('kamis');
			$jumat = $this->input->post('jumat');
			$sabtu = $this->input->post('sabtu');
			$data = array(
				'kelas'=>$kelas,
				'senin'=>$senin,
				'selasa'=>$selasa,
				'rabu'=>$rabu,
				'kamis'=>$kamis,
				'jumat'=>$jumat,
				'sabtu'=>$sabtu
			);

				$this->M_jadwal->edit_jadwal($data, $id_jadwal);
				
				redirect('Jadwal');

			}else{
				$data['log'] = $this->m_log->tampil_log();
				$data['jadwal'] = $this->M_jadwal->ambil_jadwal($id_jadwal);
				$this->load->view('admin/header',$data);
				$this->load->view('jadwal/edit_jadwal', $data);
				$this->load->view('admin/footer');
			
			}
		}
		function hapus($id_jadwal){
			$this->load->model('M_jadwal');
			$this->M_jadwal->hapus_jadwal($id_jadwal);
			redirect('jadwal');
		}
	}
 ?>