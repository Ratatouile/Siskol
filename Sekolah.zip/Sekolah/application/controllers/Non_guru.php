<?php 
	/**
	* 
	*/
	class Non_guru extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			if($this->session->userdata('status') != "login"){
			redirect(base_url("login"));
			}
			$this->load->model('Mnguru');
			$this->load->model('m_log');
			$this->load->helper('url');
		}
		function index(){
			$data['log'] = $this->m_log->tampil_log();
			$data['non_guru'] = $this->Mnguru->tampil_nonguru()->result();
			$this->load->view('admin/header',$data);
			$this->load->view('non_guru/non_guru',$data);
			$this->load->view('admin/footer');
		}
		function tambah(){
		if(isset($_POST['submit'])){
			$nama = $this->input->post('nama');
			$tgl_lahir = $this->input->post('tgl_lahir');
			$alamat = $this->input->post('alamat');
			$status = $this->input->post('status');
			$data = array(
				'nama_non'=>$nama,
				'lahir'=>$tgl_lahir,
				'alamat'=>$alamat,
				'status'=>$status
			);

			$this->Mnguru->tambah_non($data);
			redirect('Non_guru');

		}else{
		$data['log'] = $this->m_log->tampil_log();
		$this->load->view('admin/header',$data);
		$this->load->view('non_guru/tambah_non');
		$this->load->view('admin/footer');
		}
		}
		function edit($id_non){
		if(isset($_POST['submit'])){
			
			$nama = $this->input->post('nama');
			$tgl_lahir = $this->input->post('tgl_lahir');
			$alamat = $this->input->post('alamat');
			$status = $this->input->post('status');
			$data = array(
				'nama_non'=>$nama,
				'lahir'=>$tgl_lahir,
				'alamat'=>$alamat,
				'status'=>$status
			);

				$this->Mnguru->edit_non($data, $id_non);
				
				redirect('Non_guru');

			}else{
				$data['log'] = $this->m_log->tampil_log();
				$data['non_guru'] = $this->Mnguru->ambil_non($id_non);
				$this->load->view('admin/header',$data);
				$this->load->view('non_guru/edit_non', $data);
				$this->load->view('admin/footer');
			
			}
		}
		function hapus($id_non){
			$this->load->model('Mnguru');
			$this->Mnguru->hapus_non($id_non);
			redirect('Non_guru');
		}
	}
 ?>