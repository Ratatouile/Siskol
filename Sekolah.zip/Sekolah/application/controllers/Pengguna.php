<?php 
	/**
	* 
	*/
	class Pengguna extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			if($this->session->userdata('status') != "login"){
			redirect(base_url("login"));
			}
			$this->load->Model('M_pengguna');
			$this->load->model('m_log');
			$this->load->helper('url');
		}
		function index(){
			$data['log'] = $this->m_log->tampil_log();
			$data['pengguna'] = $this->M_pengguna->tampil_pengguna()->result();
			$this->load->view('admin/header',$data);
			$this->load->view('pengguna/pengguna',$data);
			$this->load->view('admin/footer');
		}

		function tambah(){
		if(isset($_POST['submit'])){
			
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$data = array(
				// 'nip'=>$nip,
				'username'=>$username,
				'password'=>md5($password)
			);

			$this->M_pengguna->tambah_pengguna($data);
			redirect('Pengguna');

		}else{
		$data['log'] = $this->m_log->tampil_log();
		$this->load->view('admin/header',$data);
		$this->load->view('pengguna/tambah_pengguna');
		$this->load->view('admin/footer');
		}
	}
	function edit($id){
			if(isset($_POST['submit'])){

				$username = $this->input->post('username');
				$password = $this->input->post('password');				
				$data = array(
					'username'=>$username,
					'password'=>md5($password)
				);

				$this->M_pengguna->edit_pengguna($data, $id);
				
				redirect('pengguna');

			}else{
				$data['log'] = $this->m_log->tampil_log();
				$data['pengguna'] = $this->M_pengguna->ambil_pengguna($id);
				$this->load->view('admin/header',$data);
				$this->load->view('pengguna/edit_pengguna', $data);
				$this->load->view('admin/footer');
			
			}
		}

		function hapus($id){
			$this->load->model('M_pengguna');
			$this->M_pengguna->hapus_pengguna($id);
			redirect('pengguna');
		}
	}
 ?>