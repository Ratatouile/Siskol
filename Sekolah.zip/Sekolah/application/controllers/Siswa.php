<?php 
	/**
	* 
	*/
	class Siswa extends CI_Controller
	{
		
		function __construct()
		{
			parent::__construct();
			if($this->session->userdata('status') != "login"){
			redirect(base_url("login"));
		}
			$this->load->model('M_siswa');
			$this->load->model('M_guru');
			$this->load->model('m_log');
			$this->load->library('dompdf_gen');
            $this->load->helper('url');
		}
	

		function index(){
			$data['log'] = $this->m_log->tampil_log();
			$data['siswa'] = $this->M_siswa->tampil_siswa();
			$this->load->view('admin/header',$data);
			$this->load->view('siswa/siswa',$data);
			$this->load->view('admin/footer');
		}
		function cetak(){
			$data['siswa'] = $this->M_siswa->tampil_siswa();
			$this->load->view('siswa/cetak',$data);
			$paper_size = 'A4';
			$orientation = 'landscape';
			$html = $this->output->get_output();
			$this->dompdf->set_paper($paper_size,$orientation);
			// convert to PDF
			$this->dompdf->load_html($html);
			$this->dompdf->render();
			$this->dompdf->stream('Data_siswa.pdf',array('Attachment'=>0));
		}
		function tambah(){
		$data['guru'] = $this->M_guru->tampil_guru()->result();
		if(isset($_POST['submit'])){
			$nis = $this->input->post('nis');
			$nama = $this->input->post('nama_siswa');
			$kelas = $this->input->post('kelas');
			$tgl_lahir = $this->input->post('tgl_lahir');
			$alamat = $this->input->post('alamat');
			$id_guru = $this->input->post('walikelas');
			$data = array(
				'nis'=>$nis,
				'nama_siswa'=>$nama,
				'kelas'=>$kelas,
				'lahir'=>$tgl_lahir,
				'alamat'=>$alamat,
				'id_guru'=>$id_guru
			);

			$this->M_siswa->tambah_siswa($data);
			redirect('Siswa');

		}else{
		$data['log'] = $this->m_log->tampil_log();
		$this->load->view('admin/header',$data);
		$this->load->view('siswa/tambah_siswa',$data);
		$this->load->view('admin/footer');
		}
	}
	function edit($id_siswa){
		
		if(isset($_POST['submit'])){
			$nis = $this->input->post('nis');
			$nama_siswa = $this->input->post('nama_siswa');
			$kelas = $this->input->post('kelas');
			$tgl_lahir = $this->input->post('tgl_lahir');
			$alamat = $this->input->post('alamat');
			$walikelas = $this->input->post('walikelas');
			$data = array(
				'nis'=>$nis,
				'nama_siswa'=>$nama_siswa,
				'kelas'=>$kelas,
				'lahir'=>$tgl_lahir,
				'alamat'=>$alamat,
				'id_guru'=>$walikelas
			);

				$this->M_siswa->edit_siswa($data, $id_siswa);
				
				redirect('siswa');

			}else{
				$data['log'] = $this->m_log->tampil_log();
				$data['guru'] = $this->M_guru->tampil_guru()->result();
				// $data['guru'] = $this->M_guru->ambil_guru($id_guru);
				$data['siswa'] = $this->M_siswa->ambil_siswa($id_siswa);
				$this->load->view('admin/header',$data);
				$this->load->view('siswa/edit_siswa', $data);
				$this->load->view('admin/footer');
			
			}
		}
	function hapus($id_siswa){
		$this->load->model('M_siswa');
		$this->M_siswa->hapus_siswa($id_siswa);
		redirect('siswa');
	}

	}
 ?>