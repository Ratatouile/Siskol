<?php 
	class M_guru extends CI_Model{
	function tampil_guru(){
		return $this->db->get('guru');
	}
	function tambah_guru($data){
		$this->db->insert('guru', $data);
	}
	function ambil_guru($id_guru){
		$query = $this->db->get_where('guru',array(
			'id_guru'=>$id_guru
			));
		return $query->row();
	}
	function edit_guru($data, $id_guru){
		$this->db->where('id_guru', $id_guru);
		$this->db->update('guru', $data);
	}	
	function hapus_guru($id_guru){
		$this->db->where('id_guru',$id_guru);
		return $this->db->delete('guru');
	}
 }
