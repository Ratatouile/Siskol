<?php 
	class M_jadwal extends CI_Model{
		function tampil_jadwal(){
			return $this->db->get('jadwal');
		}
		function tambah_jadwal($data){
			$this->db->insert('jadwal',$data);
		}
		function ambil_jadwal($id_jadwal){
			$query = $this->db->get_where('jadwal',array(
			'id_jadwal'=>$id_jadwal
			));
		return $query->row();
		}
		function edit_jadwal($data, $id_jadwal){
			$this->db->where('id_jadwal', $id_jadwal);
			$this->db->update('jadwal', $data);
		}
		function hapus_jadwal($id_jadwal){
			$this->db->where('id_jadwal',$id_jadwal);
			return $this->db->delete('jadwal');
		}

	}
 ?>