<?php 
	class M_pengguna extends CI_Model{

		function tampil_pengguna(){
			return $this->db->get('admin');
		}
		function tambah_pengguna($data){
			$this->db->insert('admin',$data);
		}
		function ambil_pengguna($id){
		$query = $this->db->get_where('admin',array(
			'id'=>$id
			));

		return $query->row();
		}
		function edit_pengguna($data, $id){
		$this->db->where('id', $id);
		$this->db->update('admin', $data);
		}
		function hapus_pengguna($id){
			$this->db->where('id',$id);
			return $this->db->delete('admin');
		}
	}
 ?>