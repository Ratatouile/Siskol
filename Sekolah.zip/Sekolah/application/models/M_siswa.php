<?php 
 
class M_siswa extends CI_Model{
	var $tabel= 'siswa';
	
	function tampil_siswa(){
    $this->db->select(array(
      
      'siswa.id_siswa',
      'siswa.nis',
      'siswa.nama_siswa',
      'siswa.kelas',
      'siswa.lahir',
      'siswa.alamat',
      'siswa.id_guru',
      'guru.*'));
    $this->db->join('guru','guru.id_guru = siswa.id_guru','LEFT');
    $this->db->order_by('siswa.kelas','ASC');
    $this->db->from($this->tabel);

    $query = $this->db->get();

    return $query->result();
  }
	function tambah_siswa($data){
		$this->db->insert('siswa', $data);
	}
	function ambil_siswa($id_siswa){
		$query = $this->db->get_where('siswa',array(
			'id_siswa'=>$id_siswa
			));
		return $query->row();
	}
	function edit_siswa($data, $id_siswa){
		$this->db->where('id_siswa', $id_siswa);
		$this->db->update('siswa', $data);
	}
	function hapus_siswa($id_siswa){
		$this->db->where('id_siswa',$id_siswa);
		return $this->db->delete('siswa');
	}
	

}