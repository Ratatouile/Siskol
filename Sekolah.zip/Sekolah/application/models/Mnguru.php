<?php 
	class Mnguru extends CI_Model{
	function tampil_nonguru(){
		return $this->db->get('non_guru');
	}
	function tambah_non($data){
		$this->db->insert('non_guru', $data);
	}
	function ambil_non($id_non){
		$query = $this->db->get_where('non_guru',array(
			'id_non'=>$id_non
			));
		return $query->row();
	}
	function edit_non($data, $id_non){
		$this->db->where('id_non', $id_non);
		$this->db->update('non_guru', $data);
	}
	function hapus_non($id_non){
		$this->db->where('id_non',$id_non);
		return $this->db->delete('non_guru');
	}
}	