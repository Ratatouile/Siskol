<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class M_log extends CI_Model {
 
    public function save_log($param)
    {
        $sql        = $this->db->insert_string('tabel_log',$param);
        $ex         = $this->db->query($sql);
        return $this->db->affected_rows($sql);
    }
    function tampil_log(){
		$this->db->order_by('log_time','DESC');
		$query = $this->db->get('tabel_log');

		return $query->result();
	}
	function hapus_log($log_id){
		$this->db->where('log_id',$log_id);
		return $this->db->delete('tabel_log');
	}
	function clear(){
		$this->db->empty_table('tabel_log');
	}

}