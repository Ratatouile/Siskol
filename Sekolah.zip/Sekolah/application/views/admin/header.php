<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <meta name="description" content="">
    <meta name="author" content="">
    <title>SISKOL</title>

    <!-- Bootstrap core CSS -->
    <link href="<?php echo base_url('assets/vendor/bootstrap/css/bootstrap.min.css');?>" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="<?php echo base_url('assets/vendor/font-awesome/css/font-awesome.min.css');?>" rel="stylesheet" type="text/css">

    <!-- Plugin CSS -->
    <link href="<?php echo base_url('assets/vendor/datatables/dataTables.bootstrap4.css');?>" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="<?php echo base_url('assets/css/sb-admin.css');?>" rel="stylesheet">
    
  </head>

  <body class="fixed-nav" id="page-top">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
      <a class="navbar-brand" href="<?php echo base_url('Admin') ?>"><i class="fa fa-fw fa-bank"></i> Sistem Informasi Data Sekolah <b>(SISKOL)</b></a>
      <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav navbar-sidenav">
          <li class="nav-item active" data-toggle="tooltip" data-placement="right" title="Dashboard">
            <a class="nav-link" href="<?php echo base_url('admin') ?>">
              <i class="fa fa-fw fa-window-maximize"></i>
              <span class="nav-link-text">
                Dashboard</span>
            </a>
          </li>
          <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Data Siswa">
            <a class="nav-link" href="<?php echo base_url('siswa') ?>">
              <i class="fa fa-fw fa-user-circle"></i>
              <span class="nav-link-text">
                Data Siswa</span>
            </a>
          </li>
          <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Data Guru">
            <a class="nav-link" href="<?php echo base_url('guru') ?>">
              <i class="fa fa-fw fa-graduation-cap"></i>
              <span class="nav-link-text">
                Data Guru</span>
            </a>
          </li>
          <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Non Guru">
            <a class="nav-link" href="<?php echo base_url('Non_guru') ?>">
              <i class="fa fa-fw fa-user"></i>
              <span class="nav-link-text">
                Data Non Guru</span>
            </a>
          </li>
          <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Jadwal">
            <a class="nav-link" href="<?php echo base_url('jadwal') ?>">
              <i class="fa fa-fw fa-table"></i>
              <span class="nav-link-text">
                Jadwal Pelajaran</span>
            </a>
          </li>
          <li class="nav-item" data-toggle="tooltip" data-placement="right" title="Tools">
            <a class="nav-link nav-link-collapse collapsed" data-toggle="collapse" href="#collapseComponents">
              <i class="fa fa-fw fa-wrench"></i>
              <span class="nav-link-text">
                Tools</span>
            </a>
            <ul class="sidenav-second-level collapse" id="collapseComponents">
              <li>
                <a href="<?php echo base_url('pengguna') ?>">Data Pengguna</a>
              </li>
              <li>
                <a href="<?php echo base_url('Admin/log') ?>">Log Login</a>
              </li>
    
            </ul>
          </li>
          
        </ul>
        <ul class="navbar-nav sidenav-toggler">
          <li class="nav-item">
            <a class="nav-link text-center" id="sidenavToggler">
              <i class="fa fa-fw fa-angle-left"></i>
            </a>
          </li>
        </ul>
        <ul class="navbar-nav ml-auto">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle mr-lg-2" href="#" id="messagesDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fa fa-fw fa-bars"></i>
              <span class="d-lg-none">Log Login
                <span class="badge badge-pill badge-primary"> Data</span>
              </span>
              <span class="new-indicator text-primary d-none d-lg-block">
                <i class="fa fa-fw fa-circle"></i>
                <span class="number">
                  <?php 
                  $no = 1;
                  foreach($log as $u){ ?>
                    <?php $no++ ;?>
                  <?php } ?>
                  <?php echo $no-1;?>
                </span>
              </span>
            </a>
            <div class="dropdown-menu" aria-labelledby="messagesDropdown">
              <h6 class="dropdown-header">Log Login:</h6>
              <?php 
                  foreach($log as $u){ ?>
              
              <div class="dropdown-divider"></div>
              <a class="dropdown-item">
                <strong><?php echo $u->log_user; ?></strong>
                <span class="small float-right text-muted"><?php echo $u->log_time; ?></span>
              </a>
              
              <div class="dropdown-divider"></div>
              <?php } ?>
              <a class="dropdown-item small" href="<?php echo base_url('Admin/log') ?>">
                <b>Lihat Semua Log Login</b>
              </a>
            </div>
          </li>
          
          <li class="nav-item">
            <form class="form-inline my-2 my-lg-0 mr-lg-2">
              <div class="input-group">
                <input type="text" class="form-control" placeholder="Search for...">
                <span class="input-group-btn">
                  <button class="btn btn-primary" type="button">
                    <i class="fa fa-search"></i>
                  </button>
                </span>
              </div>
            </form>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
              <i class="fa fa-fw fa-sign-out"></i>
              Logout</a>
          </li>
        </ul>
      </div>
    </nav>