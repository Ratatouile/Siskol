<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Cetak PDF</title>
<style>
	table{
		border-collapse: collapse;
		width: 100%;
		margin: 0 auto;

	}
	table th{
		border: 1px solid #000;
		padding: 3px;
		font-weight: bold;
		text-align: center;
		background-color: #D00404;
	}
	table td{
		border: 1px solid #000;
		padding: 3px;
		vertical-align: top;
	}
	
</style>
</head>
<body>
	<p style="text-align: center;">
		<b><u>Data Guru</u></b><hr>
	</p>
	<table>
		<tr>
			<th style="width: 4%">NO</th>
			<th style="width: 20%;">
				NIP
			</th>
			<th>Nama</th>
            <th>Tgl Lahir</th>
            <th>Alamat</th>
            <th>Status</th>
		</tr>
		<?php $no=0; 
		foreach($guru as $u){
			$no++;
			?>
			<tr>
				<td><?php echo $no;?></td>
				<td><?php echo $u->nip; ?></td>
                <td><?php echo $u->nama; ?></td>
                <td><?php echo $u->lahir; ?></td>
                <td><?php echo $u->alamat; ?></td>
                <td><?php echo $u->status; ?></td>
			</tr>
			<?php };?>
	</table>	
</body>
</html>