  
 <div class="content-wrapper py-3">

      <div class="container-fluid">
 <div class="card mb-3">
          <div class="card-header">
            <i class="fa fa-graduation-cap"></i>
            Data Guru
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" width="100%" id="dataTable" cellspacing="0">
                <thead>
                 <th><a href="<?php echo base_url('guru/tambah'); ?>"><button class="btn btn-success">Tambah Data</button></a>
                <th><a href="<?php echo base_url('guru/Cetak'); ?>" target="blank"><button class="btn btn-danger">Cetak</button></a></th><th></th>
                  <tr>
                  	<th>NIP</th>
                    <th>Nama</th>
                    <th>Tgl Lahir</th>
                    <th>Alamat</th>
                    <th>Status</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>
                  	<th>NIP</th>
                    <th>Nama</th>
                    <th>Tgl Lahir</th>
                    <th>Alamat</th>
                    <th>Status</th>
                    <th>Aksi</th>
                    </tr>
                </tfoot>
                <tbody>
                <?php 
                
				foreach($guru as $u){ 
				?>
                  <tr>
                  
                    <td><?php echo $u->nip; ?></td>
                    <td><?php echo $u->nama; ?></td>
                    <td><?php echo $u->lahir; ?></td>
                    <td><small><?php echo $u->alamat; ?></small></td>
                    <td><?php echo $u->status; ?></td>
                  	<td>
                    <?php echo anchor('guru/edit/'.$u->id_guru,'Edit',array('class'=>'btn btn-info', 'title'=>'Edit Data Guru'));?>
                  	<?php echo anchor('guru/hapus/'.$u->id_guru,'Hapus',array('class'=>'btn btn-danger', 'title'=>'Hapus Data Guru','onclick'=>"return confirm('Yakin mau hapus data ini?')"));?>
					         </td>
                  
                  </tr>
                  <?php } ?>
                
                </tbody>
              </table>
            </div>
          </div>