<div class="content-wrapper py-3">

      <div class="container-fluid">      
        <!-- Example Tables Card -->
       <a href="<?php echo base_url('guru') ?>"><button class="btn btn-info">Lihat Semua Data</button></a>
 
	<br/>
	<h3>Input data baru</h3>
	<div class="table-responsive">
  <?php echo form_open('guru/tambah');?>
      <table class="table table-striped">
        <tr>
          <th>NIP</th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'nip', 
                  'class'=>'form-control',
                  'id'=>'nip',
                  'autofocus'=>'autofocus',
                  'required'=>'required'));?>
          </th>
        </tr>
        <tr>
          <th>Nama</th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'nama', 
                  'class'=>'form-control',
                  'id'=>'nama',
                  'autofocus'=>'autofocus',
                  'required'=>'required'));?>
          </th>
        </tr>

        <tr>
          <th>tanggal lahir<br> </th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'tgl_lahir', 
                  'class'=>'form-control',
                  'id'=>'tgl_lahir',
                  'type'=> 'date',
                  'autofocus'=>'autofocus',
                  'required'=>'required'));?>
          </th>
        </tr>

        <tr>
          <th>Alamat</th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'alamat', 
                  'class'=>'form-control',
                  'id'=>'alamat',
                  'autofocus'=>'autofocus',
                  'required'=>'required'));?>
          </th>
       </tr>
        <tr>
                  <th>Status</th>
                  <th>:</th>
                  <td>
                  <select name="status" class="form-control">
                  <?php
                    $status = array(
                  
                      'Belum Menikah'=>'Belum Menikah',
                      'sudah Menikah'=>'Sudah Menikah'
                      );
                    foreach($status as $row=>$value):
                      echo '<option value="'.$row.'">'.$value.'</option>';
                      endforeach;
                  ?>
                  </select>
        <tr>
          <th colspan="3">
            <?php echo form_submit(array(
              'name'=>'submit',
              'id'=>'submit',
              'value'=>'Simpan Data',
              'class'=>'btn btn-success'
            ));?>
           
          </th>
        </tr>				
		</table>
	</form>
	</div>
	</div>
</div>