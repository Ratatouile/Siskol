<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Cetak PDF</title>
<style>
	table{
		border-collapse: collapse;
		width: 100%;
		margin: 0 auto;

	}
	table th{
		border: 1px solid #000;
		padding: 3px;
		font-weight: bold;
		text-align: center;
		background-color: #969696;
	}
	table td{
		border: 1px solid #000;
		padding: 3px;
		vertical-align: top;
	}
	
</style>
</head>
<body>
	<p style="text-align: center;">
		<b><u>Jadwal Pelajaran</u></b><hr>
	</p>
	<table>
		<tr>
			<th style="width: 7%;">Kelas</th>
			<th>Senin</th>
			<th>Selasa</th>
            <th>Rabu</th>
            <th>Kamis</th>
            <th>Jumat</th>
            <th>Sabtu</th>
		</tr>
		 <?php 
				foreach($jadwal as $u){ 
				?>
                  <tr>
                    <td><?php echo $u->kelas; ?></td>
                    <td><?php echo $u->senin; ?></td>
                    <td><?php echo $u->selasa; ?></td>
                    <td><?php echo $u->rabu; ?></td>
                    <td><?php echo $u->kamis; ?></td>
                    <td><?php echo $u->jumat; ?></td>
                    <td><?php echo $u->sabtu; ?></td>
			</tr>
			<?php };?>
	</table>	
</body>
</html>