<div class="content-wrapper py-3">

      <div class="container-fluid">      
        <!-- Example Tables Card -->
       
 
	<br/>
	<h3>Edit Jadwal</h3>
	<div class="table-responsive">
  <?php echo form_open('jadwal/edit/'.$jadwal->id_jadwal);?>
      <table class="table table-striped">
        <tr>
          <th>Kelas</th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'kelas', 
                  'class'=>'form-control',
                  'id'=>'kelas',
                  'autofocus'=>'autofocus',
                  'required'=>'required',
                  'value'=>$jadwal->kelas));?>
          </th>
        </tr>
        <tr>
          <th>Senin</th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'senin', 
                  'class'=>'form-control',
                  'id'=>'senin',
                  'autofocus'=>'autofocus',
                  'required'=>'required',
                  'value'=>$jadwal->senin));?>
          </th>
        </tr>
        
        <tr>
          <th>Selasa</th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'selasa', 
                  'class'=>'form-control',
                  'id'=>'selasa',
                  'autofocus'=>'autofocus',
                  'required'=>'required',
                  'value'=>$jadwal->selasa));?>
          </th>
        </tr>

        <tr>
          <th>Rabu</th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'rabu', 
                  'class'=>'form-control',
                  'id'=>'rabu',
                  'autofocus'=>'autofocus',
                  'required'=>'required',
                  'value'=>$jadwal->rabu));?>
          </th>
        </tr>
        <tr>
          <th>Kamis</th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'kamis', 
                  'class'=>'form-control',
                  'id'=>'kamis',
                  'autofocus'=>'autofocus',
                  'required'=>'required',
                  'value'=>$jadwal->kamis));?>
          </th>
        </tr>
        <tr>
          <th>Jumat</th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'jumat', 
                  'class'=>'form-control',
                  'id'=>'jumat',
                  'autofocus'=>'autofocus',
                  'required'=>'required',
                  'value'=>$jadwal->jumat));?>
          </th>
        </tr>
        <tr>
          <th>Sabtu</th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'sabtu', 
                  'class'=>'form-control',
                  'id'=>'sabtu',
                  'autofocus'=>'autofocus',
                  'required'=>'required',
                  'value'=>$jadwal->sabtu));?>
          </th>
        </tr>
        <tr>
          <th colspan="3">
            <?php echo anchor('jadwal','Kembali',array('class'=>'btn btn-info', 'title'=>'Kembali'));?>
            <?php echo form_submit(array(
              'name'=>'submit',
              'id'=>'submit',
              'value'=>'Simpan Data',
              'class'=>'btn btn-success'
            ));?>
            
          </th>
        </tr>				
		</table>
	</form>
	</div>
	</div>
</div>