 <div class="content-wrapper py-3">

      <div class="container-fluid">
 <div class="card mb-3">
          <div class="card-header">
            <i class="fa fa-table"></i>
            Jadwal Belajar
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" width="100%" id="dataTable" cellspacing="0">
                <thead>
                 <th><a href="<?php echo base_url('Jadwal/tambah'); ?>"><button class="btn btn-success">Tambah Data</button></a></th>
                 <th><a href="<?php echo base_url('Jadwal/cetak'); ?>" target='blank'><button class="btn btn-danger">Cetak</button></a></th><th></th>
                  <tr>
                  	<th>Kelas</th>
                    <th>Senin</th>
                    <th>Selasa</th>
                    <th>Rabu</th>
                    <th>Kamis</th>
                    <th>Jum'at</th>
                    <th>Sabtu</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>
                  	<th>Kelas</th>
                    <th>Senin</th>
                    <th>Selasa</th>
                    <th>Rabu</th>
                    <th>Kamis</th>
                    <th>Jum'at</th>
                    <th>Sabtu</th>
                    <th>Aksi</th>
                    </tr>
                </tfoot>
                <tbody>
                <?php 
				foreach($jadwal as $u){ 
				?>
                  <tr>
                    <td><small><?php echo $u->kelas; ?></small></td>
                    <td><small><?php echo $u->senin; ?></small></td>
                    <td><small><?php echo $u->selasa; ?></small></td>
                    <td><small><?php echo $u->rabu; ?></small></td>
                    <td><small><?php echo $u->kamis; ?></small></td>
                    <td><small><?php echo $u->jumat; ?></small></td>
                    <td><small><?php echo $u->sabtu; ?></small></td>
                  	<td>
                    <?php echo anchor('jadwal/edit/'.$u->id_jadwal,'Edit',array('class'=>'btn btn-info', 'title'=>'Edit Jadwal'));?>
                  	<?php echo anchor('jadwal/hapus/'.$u->id_jadwal,'Hapus',array('class'=>'btn btn-danger', 'title'=>'Hapus jadwal','onclick'=>"return confirm('Yakin mau hapus data ini?')"));?>
					         </td>
                  
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>