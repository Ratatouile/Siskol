 <div class="content-wrapper py-3">

      <div class="container-fluid">
 <div class="card mb-3">
          <div class="card-header">
            <i class="fa fa-bars"></i>
            Log Login
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" width="100%" id="dataTable" cellspacing="0">
                <thead>
                <th><a href="<?php echo base_url('Admin/clear'); ?>"><button class="btn btn-info">Clear</button></a></th>
                  <tr>
                  	<th>No</th>
                    <th>Waktu</th>
                    <th>Username</th>
                    <th>Deskripsi</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>
                  	<th>No</th>
                    <th>Waktu</th>
                    <th>Username</th>
                    <th>Deskripsi</th>
                    <th>Aksi</th></tr>
                </tfoot>
                <tbody>
                <?php 
                $no = 1;
				foreach($log as $u){

				?>
                  <tr>
                    <td><?php echo $no++ ; ?></td>
                    <td><?php echo $u->log_time; ?></td>
                    <td><?php echo $u->log_user; ?></td>
                    <td><?php echo $u->log_desc; ?></td>
                  	<td>
                  	<?php echo anchor('Admin/hapus/'.$u->log_id,'Hapus',array('class'=>'btn btn-danger', 'title'=>'Hapus Data'));?>
                    </td>

					         
                   
                  
                  </tr>
                  <?php } ?>
                
                </tbody>
              </table>
            </div>
          </div>