 <head>
  <meta charset="UTF-8">
  <title>login form</title>
  
  <link rel="stylesheet" href="<?php echo base_url() ;?>login/css/reset.min.css">

  
  <link href="<?php echo base_url('assets/login/css/style2.css');?>" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url('assets/login/css/style.css');?>" rel="stylesheet" type="text/css">    

  <script src="<?php echo base_url() ;?>login/js/prefixfree.min.js"></script>

</head>

<style> .back { background: url('<?php echo base_url('/assets/login/back.jpg');?>') left top no-repeat; }</style>
<body class="back">
<form action="<?php echo base_url('login/aksi_login'); ?>" method="post">
<div class="login">
  <header class="login-header"><span class="text">LOGIN</span><span class="loader"></span></header>
  <form class="login-form">
    <input class="login-input" type="text" placeholder="username" name="username" />
    <input class="login-input" type="password" placeholder="password" name="password" />
    <button class="login-btn" type="submit">login</button>
  </form>
</div>
</form>
  <script src='<?php echo base_url() ;?>login/js/jquery.min.js'></script>

    <script  src="<?php echo base_url() ;?>login/js/index.js"></script>

</body>
</html>
