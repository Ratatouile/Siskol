 <div class="content-wrapper py-3">

      <div class="container-fluid">
 <div class="card mb-3">
          <div class="card-header">
            <i class="fa fa-user"></i>
            Data Pegawai Non Guru
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" width="100%" id="dataTable" cellspacing="0">
                <thead>
                 <th><a href="<?php echo base_url('Non_guru/tambah'); ?>"><button class="btn btn-success">Tambah Data</button></a></th>
                  <tr>
                  	<th>No</th>
                    <th>Nama</th>
                    <th>Tgl Lahir</th>
                    <th>Alamat</th>
                    <th>Status</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>
                  	<th>No</th>
                    <th>Nama</th>
                    <th>Tgl Lahir</th>
                    <th>Alamat</th>
                    <th>Status</th>
                    <th>Aksi</th>
                    </tr>
                </tfoot>
                <tbody>
                <?php 
                $no = 1;
				foreach($non_guru as $u){ 
				?>
                  <tr>
                  
                    <td><?php echo $no++ ; ?></td>
                    <td><?php echo $u->nama_non; ?></td>
                    <td><?php echo $u->lahir; ?></td>
                    <td><?php echo $u->alamat; ?></td>
                    <td><?php echo $u->status; ?></td>
                  	<td>
                    <?php echo anchor('Non_guru/edit/'.$u->id_non,'Edit',array('class'=>'btn btn-info', 'title'=>'Edit Data'));?>
                  	<?php echo anchor('Non_guru/hapus/'.$u->id_non,'Hapus',array('class'=>'btn btn-danger', 'title'=>'Hapus Data','onclick'=>"return confirm('Yakin mau hapus data ini?')"));?>
					         </td>
                  
                  </tr>
                  <?php } ?>
                
                </tbody>
              </table>
            </div>
          </div>