 <div class="content-wrapper py-3">

      <div class="container-fluid">
 <div class="card mb-3">
          <div class="card-header">
            <i class="fa fa-key"></i>
            Data Pengguna
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" width="100%" id="dataTable" cellspacing="0">
                <thead>
                 <th><a href="<?php echo base_url('pengguna/tambah'); ?>"><button class="btn btn-success">Tambah Pengguna</button></a></th>
                  <tr>
                  	<th>NO</th>
                    <th>Username</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>
                  	<th>NO</th>
                    <th>Username</th>
                    <th>Aksi</th>
                    </tr>
                </tfoot>
                <tbody>
                <?php 
                $no = 1;
				foreach($pengguna as $u){ 
				?>
                  <tr>
                    <td><?php echo $no++; ?></td>
                    <td><?php echo $u->username; ?></td>
                    
                  	<td><?php echo anchor('pengguna/Edit/'.$u->id,'Edit',array('class'=>'btn btn-info', 'title'=>'Edit Data Pengguna'));?>
                  	<?php echo anchor('pengguna/hapus/'.$u->id,'Hapus',array('class'=>'btn btn-danger', 'title'=>'Hapus Data Pengguna','onclick'=>"return confirm('Yakin mau hapus data ini?')"));?>
					         </td>
                  
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>