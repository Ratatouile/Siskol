<div class="content-wrapper py-3">

      <div class="container-fluid">      
        <!-- Example Tables Card -->
       <a href="<?php echo base_url('pengguna') ?>"><button class="btn btn-info">Lihat Semua Data</button></a>
 
	<br/>
	<h3>Input data baru</h3>
	<div class="table-responsive">
  <?php echo form_open('pengguna/tambah');?>
      <table class="table table-striped">
        <tr>
          <th>Username</th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'username', 
                  'class'=>'form-control',
                  'id'=>'username',
                  'autofocus'=>'autofocus',
                  'required'=>'required'));?>
          </th>
        </tr>

        <tr>
          <th>Password</th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'password', 
                  'class'=>'form-control',
                  'type'=>'password',
                  'id'=>'Password',
                  'autofocus'=>'autofocus',
                  'required'=>'required'));?>
          </th>
        </tr>
        <tr>
          <th colspan="3">
            <?php echo form_submit(array(
              'name'=>'submit',
              'id'=>'submit',
              'value'=>'Simpan Data',
              'class'=>'btn btn-success'
            ));?>
           
          </th>
        </tr>				
		</table>
	</form>
	</div>
	</div>
</div>