<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Cetak PDF</title>
<style>
	table{
		border-collapse: collapse;
		width: 100%;
		margin: 0 auto;

	}
	table th{
		border: 1px solid #000;
		padding: 3px;
		font-weight: bold;
		text-align: center;
		background-color: #01BA01;
	}
	table td{
		border: 1px solid #000;
		padding: 3px;
		vertical-align: top;
	}
	
</style>
</head>
<body>
	<p style="text-align: center;">
		<b><u>Data Siswa</u></b><hr>
	</p>
	<table>
		<tr>
			<th style="width: 4%">NO</th>
			<th style="width: 20%;">
				NIS
			</th>
			<th>Nama</th>
            <th>Kelas</th>
            <th>Tgl Lahir</th>
            <th>Alamat</th>
            <th>Wali Kelas</th>
		</tr>
		<?php $no=0; 
		foreach($siswa as $u){
			$no++;
			?>
			<tr>
				<td><?php echo $no;?></td>
				<td><?php echo $u->nis; ?></td>
                <td><?php echo $u->nama_siswa; ?></td>
                <td><?php echo $u->kelas; ?></td>
                <td><?php echo $u->lahir; ?></td>
                <td><?php echo $u->alamat; ?></td>
                <td><?php echo $u->nama; ?></td>
			</tr>
			<?php };?>
	</table>	
</body>
</html>