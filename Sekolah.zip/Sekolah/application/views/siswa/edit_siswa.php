<div class="content-wrapper py-3">

      <div class="container-fluid">      
        <!-- Example Tables Card -->
       <a href="<?php echo base_url('siswa') ?>"><button class="btn btn-info">Lihat Semua Data</button></a>
 
	<br/>
	<h3>Input Data Siswa</h3>
	<div class="table-responsive">
  <?php echo form_open('siswa/edit/'.$siswa->id_siswa);?>
      <table class="table table-striped">
        <tr>
          <th>NIS</th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'nis', 
                  'class'=>'form-control',
                  'id'=>'nis',
                  'autofocus'=>'autofocus',
                  'required'=>'required',
                  'value'=>$siswa->nis));?>
          </th>
        </tr>
        <tr>
          <th>Nama</th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'nama_siswa', 
                  'class'=>'form-control',
                  'id'=>'nama_siswa',
                  'autofocus'=>'autofocus',
                  'required'=>'required',
                  'value'=>$siswa->nama_siswa));?>
          </th>
        </tr>
        
        <tr>
          <th>Kelas</th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'kelas', 
                  'class'=>'form-control',
                  'id'=>'kelas',
                  'autofocus'=>'autofocus',
                  'required'=>'required',
                  'value'=>$siswa->kelas));?>
          </th>
        </tr>

        <tr>
          <th>tanggal lahir<br></th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'tgl_lahir', 
                  'class'=>'form-control',
                  'id'=>'tgl_lahir',
                  'type'=>'date',
                  'autofocus'=>'autofocus',
                  'required'=>'required',
                  'value'=>$siswa->lahir));?>
          </th>
        </tr>

        <tr>
          <th>Alamat</th>
          <th>:</th>
          <th><?php echo form_input(array(
                  'name'=>'alamat', 
                  'class'=>'form-control',
                  'id'=>'alamat',
                  'autofocus'=>'autofocus',
                  'required'=>'required',
                  'value'=>$siswa->alamat
                  ));?>
          </th>
        </tr>
        <tr>
          <th>Wali Kelas</th>
          <th>:</th>
          <th><select name="walikelas" class="form-control" required="required">
               <option value="<?php echo $siswa->id_guru?>">-- Pilih Wali Kelas --</option>
              <?php
                  foreach ($guru as $a) {?>
                    <option value="<?php echo $a->id_guru?>"><?php echo $a->nama?></option>
                  <?php
                  }
              ?>
          </select>
          </th>
        </tr>
        <tr>
          <th colspan="3">
            <?php echo form_submit(array(
              'name'=>'submit',
              'id'=>'submit',
              'value'=>'Simpan Data',
              'class'=>'btn btn-success'
            ));?>
           
          </th>
        </tr>				
		</table>
	</form>
	</div>
	</div>
</div>