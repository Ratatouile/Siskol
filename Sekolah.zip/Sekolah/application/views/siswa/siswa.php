 <div class="content-wrapper py-3">

      <div class="container-fluid">
 <div class="card mb-3">
          <div class="card-header">
            <i class="fa fa-user-circle"></i>
            Data Siswa
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table table-bordered" width="100%" id="dataTable" cellspacing="0">
                <thead>
                 <th><a href="<?php echo base_url('siswa/tambah'); ?>"><button class="btn btn-success">Tambah Data</button></a></th>
                 <th><a href="<?php echo base_url('siswa/cetak'); ?>" target="blank"><button class="btn btn-danger">Cetak</button></a></th><th></th>
                  <tr>
                  	<th>NIS</th>
                    <th>Nama</th>
                    <th>Kelas</th>
                    <th>Tgl Lahir</th>
                    <th>Alamat</th>
                    <th>Wali kelas</th>
                    <th>Aksi</th>
                  </tr>
                </thead>
                <tfoot>
                  <tr>
                  	<th>NIS</th>
                    <th>Nama</th>
                    <th>Kelas</th>
                    <th>Tgl Lahir</th>
                    <th>Alamat</th>
					          <th>Wali kelas</th> 
                    <th>Aksi</th>
                    </tr>
                </tfoot>
                <tbody>
                <?php 
				foreach($siswa as $u){ 
				?>
                  <tr>
                    <td><?php echo $u->nis; ?></td>
                    <td><?php echo $u->nama_siswa; ?></td>
                    <td><?php echo $u->kelas; ?></td>
                    <td><?php echo $u->lahir; ?></td>
                    <td><small><?php echo $u->alamat; ?></small></td>
                    <td><?php echo $u->nama; ?></td>
                  	<td>
                    <?php echo anchor('siswa/edit/'.$u->id_siswa,'Edit',array('class'=>'btn btn-info', 'title'=>'Edit Data Siswa'));?>
                  	<?php echo anchor('siswa/hapus/'.$u->id_siswa,'Hapus',array('class'=>'btn btn-danger', 'title'=>'Hapus Data Siswa','onclick'=>"return confirm('Yakin mau hapus data ini?')"));?>
					         </td>
                  
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
          </div>